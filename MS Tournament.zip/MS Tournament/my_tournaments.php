<?php 
require 'common/config.php';
auth_user();
$uid = $_SESSION['user_id'];
$tab = $_GET['tab'] ?? 'ongoing';
include 'common/header.php';
?>

<div class="flex bg-gray-800 p-1 rounded-2xl mb-8">
    <a href="?tab=ongoing" class="w-1/2 py-3 text-center rounded-xl font-bold <?php echo $tab=='ongoing' ? 'bg-yellow-500 text-black' : 'text-gray-500'; ?>">Ongoing</a>
    <a href="?tab=completed" class="w-1/2 py-3 text-center rounded-xl font-bold <?php echo $tab=='completed' ? 'bg-yellow-500 text-black' : 'text-gray-500'; ?>">Completed</a>
</div>

<div class="space-y-6">
<?php
if($tab == 'completed'):
    $res = $conn->query("SELECT t.*, p.kills, p.rank, p.winnings FROM tournaments t JOIN participants p ON t.id = p.tournament_id WHERE p.user_id = $uid AND t.status='Completed' ORDER BY t.id DESC");
    if($res->num_rows == 0) echo "<p class='text-center py-20 text-gray-600'>No completed matches.</p>";
    while($row = $res->fetch_assoc()):
?>
    <div class="bg-gray-800 p-6 rounded-3xl border border-gray-700 shadow-xl relative overflow-hidden">
        <div class="flex justify-between items-start mb-6">
            <div> <h3 class="text-lg font-black text-white italic uppercase logo-font"><?php echo $row['title']; ?></h3> <p class="text-xs text-gray-500"><?php echo $row['game_name']; ?></p> </div>
            <div class="text-right"> <p class="text-[9px] text-gray-500 uppercase font-bold">Winnings</p> <p class="text-xl font-black text-green-500 italic">₹<?php echo $row['winnings']; ?></p> </div>
        </div>
        <div class="grid grid-cols-2 gap-4 bg-gray-900/50 p-4 rounded-2xl border border-gray-700">
            <div class="text-center"> <p class="text-[10px] text-gray-500 uppercase">Kills</p> <p class="font-black text-yellow-500 text-lg"><?php echo $row['kills']; ?></p> </div>
            <div class="text-center border-l border-gray-700"> <p class="text-[10px] text-gray-500 uppercase">Rank</p> <p class="font-black text-blue-500 text-lg">#<?php echo $row['rank']; ?></p> </div>
        </div>
    </div>
<?php endwhile; else:
    $res = $conn->query("SELECT t.* FROM tournaments t JOIN participants p ON t.id = p.tournament_id WHERE p.user_id = $uid AND t.status IN ('Upcoming', 'Live') ORDER BY t.id DESC");
    if($res->num_rows == 0) echo "<p class='text-center py-20 text-gray-600'>No ongoing matches.</p>";
    while($row = $res->fetch_assoc()):
?>
    <div class="bg-gray-800 p-6 rounded-3xl border border-gray-700 shadow-xl">
        <h3 class="text-lg font-black text-white italic uppercase mb-2"><?php echo $row['title']; ?></h3>
        <p class="text-xs text-gray-500 mb-4"><?php echo date('d M, h:i A', strtotime($row['match_time'])); ?></p>
        <?php if($row['status'] == 'Live'): ?>
            <div class="bg-yellow-500/10 border border-yellow-500/30 p-4 rounded-2xl">
                <p class="text-yellow-500 text-[10px] font-bold uppercase mb-2">Room Details (Match Live)</p>
                <div class="flex justify-between mb-1"><span class="text-xs text-gray-400">Room ID:</span> <span class="text-sm font-bold text-white"><?php echo $row['room_id']; ?></span></div>
                <div class="flex justify-between"><span class="text-xs text-gray-400">Password:</span> <span class="text-sm font-bold text-white"><?php echo $row['room_password']; ?></span></div>
            </div>
        <?php else: ?>
            <div class="bg-gray-900 p-3 rounded-xl border border-gray-700 text-center text-[10px] text-gray-500 font-bold uppercase italic tracking-widest">Room ID will appear when match starts</div>
        <?php endif; ?>
    </div>
<?php endwhile; endif; ?>
</div>
<?php include 'common/bottom.php'; ?>