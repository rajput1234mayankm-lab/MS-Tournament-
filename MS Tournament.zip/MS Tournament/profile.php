<?php 
require 'common/config.php';
auth_user();
$uid = $_SESSION['user_id'];
$msg = "";

if (isset($_POST['update_profile'])) {
    $email = clean($_POST['email']);
    $upi = clean($_POST['upi_id']);
    $conn->query("UPDATE users SET email='$email', upi_id='$upi' WHERE id=$uid");
    $msg = "Profile Updated Successfully!";
}

if (isset($_GET['logout'])) { session_destroy(); header("Location: login.php"); exit(); }

$user = $conn->query("SELECT * FROM users WHERE id=$uid")->fetch_assoc();
include 'common/header.php';
?>

<div class="text-center mt-6 mb-10">
    <div class="w-24 h-24 bg-yellow-500 rounded-full mx-auto flex items-center justify-center mb-4 shadow-xl border-4 border-gray-800">
        <i class="fas fa-user text-4xl text-black"></i>
    </div>
    <h2 class="text-2xl font-black italic uppercase logo-font"><?php echo $user['username']; ?></h2>
    <p class="text-gray-500 text-[10px] font-bold uppercase tracking-widest mt-1 italic">Member Since <?php echo date('M Y', strtotime($user['created_at'])); ?></p>
</div>

<?php if($msg) echo "<div class='bg-green-600 text-white p-4 rounded-2xl mb-8 text-center font-bold shadow-lg'>$msg</div>"; ?>

<form method="POST" class="space-y-6">
    <div class="space-y-1">
        <label class="text-[10px] text-gray-500 font-bold uppercase ml-1">Email Address</label>
        <input type="email" name="email" value="<?php echo $user['email']; ?>" class="w-full bg-gray-800 border border-gray-700 p-4 rounded-2xl text-white outline-none focus:border-yellow-500" required>
    </div>
    <div class="space-y-1">
        <label class="text-[10px] text-gray-500 font-bold uppercase ml-1">My UPI ID (For Withdrawals)</label>
        <input type="text" name="upi_id" value="<?php echo $user['upi_id']; ?>" placeholder="yourname@upi" class="w-full bg-gray-800 border border-gray-700 p-4 rounded-2xl text-white outline-none focus:border-yellow-500" required>
    </div>
    <button name="update_profile" class="w-full bg-yellow-500 text-black font-black py-4 rounded-2xl shadow-lg uppercase text-sm tracking-widest active:scale-95 transition transform">Update Account</button>
</form>

<div class="mt-12">
    <a href="?logout=1" class="flex items-center justify-center bg-red-900/20 text-red-500 font-black py-4 rounded-2xl border border-red-900/50 uppercase text-xs tracking-widest hover:bg-red-900/40 transition">
        <i class="fas fa-power-off mr-2"></i> Logout System
    </a>
</div>

<?php include 'common/bottom.php'; ?>