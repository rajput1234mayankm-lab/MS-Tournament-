<?php
require 'common/config.php';

// 1. Admin Settings Table
$conn->query("CREATE TABLE IF NOT EXISTS admin_settings (id INT PRIMARY KEY, upi_id VARCHAR(255), qr_code VARCHAR(255))");
$conn->query("INSERT IGNORE INTO admin_settings (id, upi_id, qr_code) VALUES (1, 'admin@upi', 'uploads/default_qr.png')");

// 2. Deposits Table
$conn->query("CREATE TABLE IF NOT EXISTS deposits (id INT AUTO_INCREMENT PRIMARY KEY, user_id INT, amount DECIMAL(10,2), transaction_id VARCHAR(100), status ENUM('Pending', 'Completed', 'Rejected') DEFAULT 'Pending', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");

// 3. Withdrawals Table
$conn->query("CREATE TABLE IF NOT EXISTS withdrawals (id INT AUTO_INCREMENT PRIMARY KEY, user_id INT, amount DECIMAL(10,2), status ENUM('Pending', 'Completed') DEFAULT 'Pending', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");

// 4. Check if tournaments table has new columns
$conn->query("ALTER TABLE tournaments ADD COLUMN IF NOT EXISTS per_kill DECIMAL(10,2) DEFAULT 0.00");
$conn->query("ALTER TABLE tournaments ADD COLUMN IF NOT EXISTS rank1 DECIMAL(10,2) DEFAULT 0.00");
$conn->query("ALTER TABLE tournaments ADD COLUMN IF NOT EXISTS rank2 DECIMAL(10,2) DEFAULT 0.00");
$conn->query("ALTER TABLE tournaments ADD COLUMN IF NOT EXISTS rank3 DECIMAL(10,2) DEFAULT 0.00");

echo "<h1 style='color:green; text-align:center;'>✅ ALL TABLES REPAIRED!</h1>";
echo "<p style='text-align:center;'>Ab Settings aur Login page check karein, error khatam ho gaya hoga.</p>";
?>