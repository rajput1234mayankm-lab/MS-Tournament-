<?php 
require 'common/config.php';

// Agar user pehle se login hai toh home par bhej do
if (isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$msg = "";
$msg_type = "yellow";

// 1. FETCH SUPPORT LINK SAFELY
$s_res = $conn->query("SELECT support_link FROM admin_settings WHERE id=1");
if ($s_res && $s_res->num_rows > 0) {
    $s_data = $s_res->fetch_assoc();
    $support_url = $s_data['support_link'];
} else {
    $support_url = "https://wa.me/910000000000"; 
}

// 2. SIGNUP LOGIC
if (isset($_POST['register'])) {
    $user = clean($_POST['username']);
    $email = clean($_POST['email']);
    $pass = $_POST['password'];
    $check = $conn->query("SELECT id FROM users WHERE username='$user' OR email='$email'");
    if ($check->num_rows > 0) {
        $msg = "❌ Username/Email already exists!";
        $msg_type = "red";
    } else {
        $hashed_pass = password_hash($pass, PASSWORD_DEFAULT);
        $conn->query("INSERT INTO users (username, email, password, wallet_balance, status) VALUES ('$user', '$email', '$hashed_pass', 50.00, 'Active')");
        $msg = "✅ Account Created! Please Login.";
        $msg_type = "green";
    }
}

// 3. LOGIN LOGIC
if (isset($_POST['login'])) {
    $user = clean($_POST['username']);
    $pass = $_POST['password'];
    $res = $conn->query("SELECT * FROM users WHERE username='$user'");
    if ($res->num_rows > 0) {
        $row = $res->fetch_assoc();
        if (password_verify($pass, $row['password'])) {
            if($row['status'] == 'Blocked') {
                $msg = "❌ Your account is Blocked!";
                $msg_type = "red";
            } else {
                $_SESSION['user_id'] = $row['id'];
                header("Location: index.php"); exit();
            }
        } else { $msg = "❌ Wrong Password!"; $msg_type = "red"; }
    } else { $msg = "❌ User not found!"; $msg_type = "red"; }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Login - MS TOURNAMENT</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@700;900&display=swap');
        .logo-font { font-family: 'Orbitron', sans-serif; }
        body { user-select: none; -webkit-tap-highlight-color: transparent; }
    </style>
</head>
<body class="bg-gray-900 text-white flex items-center justify-center min-h-screen p-6">

<div class="w-full max-w-sm">
    <div class="text-center mb-10">
        <h1 class="text-4xl font-black text-yellow-500 logo-font italic uppercase tracking-tighter shadow-yellow-500/20">MS TOURNAMENT</h1>
        <p class="text-gray-500 text-[10px] uppercase tracking-[0.3em] font-bold mt-2">The Ultimate Gaming Hub</p>
    </div>

    <!-- MAIN CARD -->
    <div class="bg-gray-800 p-8 rounded-[45px] shadow-2xl border border-gray-700 relative">
        <!-- Tabs -->
        <div class="flex mb-8 bg-gray-900 rounded-3xl p-1.5 border border-gray-700/50">
            <button onclick="toggleTab('login')" class="w-1/2 py-3 rounded-2xl text-center font-bold bg-yellow-500 text-black shadow-xl transition-all" id="btn-login">Login</button>
            <button onclick="toggleTab('signup')" class="w-1/2 py-3 rounded-2xl text-center font-bold text-gray-500 transition-all" id="btn-signup">Sign Up</button>
        </div>

        <?php if($msg): ?>
            <div class="bg-<?php echo $msg_type; ?>-500/10 border border-<?php echo $msg_type; ?>-500/20 text-<?php echo $msg_type; ?>-500 text-center p-3 rounded-2xl mb-6 font-bold text-xs"><?php echo $msg; ?></div>
        <?php endif; ?>

        <!-- LOGIN FORM SECTION -->
        <div id="login-form">
            <form method="POST" class="space-y-4">
                <div class="relative">
                    <i class="fas fa-user absolute left-4 top-4 text-gray-600"></i>
                    <input type="text" name="username" placeholder="Username" class="w-full bg-gray-900 border border-gray-700 p-4 pl-12 rounded-2xl focus:outline-none focus:border-yellow-500 text-white" required>
                </div>
                <div class="relative">
                    <i class="fas fa-lock absolute left-4 top-4 text-gray-600"></i>
                    <input type="password" name="password" placeholder="Password" class="w-full bg-gray-900 border border-gray-700 p-4 pl-12 rounded-2xl focus:outline-none focus:border-yellow-500 text-white" required>
                </div>
                <button type="submit" name="login" class="w-full bg-yellow-500 text-black font-black py-4 rounded-2xl shadow-lg active:scale-95 transition transform uppercase tracking-widest text-sm">Login Now</button>
            </form>
        </div>

        <!-- SIGNUP FORM SECTION -->
        <div id="signup-form" class="hidden">
            <form method="POST" class="space-y-4">
                <input type="text" name="username" placeholder="Username" class="w-full bg-gray-900 border border-gray-700 p-4 rounded-2xl focus:outline-none focus:border-yellow-500 text-white" required>
                <input type="email" name="email" placeholder="Email" class="w-full bg-gray-900 border border-gray-700 p-4 rounded-2xl focus:outline-none focus:border-yellow-500 text-white" required>
                <input type="password" name="password" placeholder="Password" class="w-full bg-gray-900 border border-gray-700 p-4 rounded-2xl focus:outline-none focus:border-yellow-500 text-white" required>
                <button type="submit" name="register" class="w-full bg-yellow-500 text-black font-black py-4 rounded-2xl shadow-lg active:scale-95 transition transform uppercase tracking-widest text-sm">Create Account</button>
            </form>
        </div>

        <!-- Support Link -->
        <div class="mt-8 text-center border-t border-gray-700 pt-6">
            <a href="<?php echo $support_url; ?>" target="_blank" class="text-[11px] font-bold text-gray-500 hover:text-yellow-500 uppercase tracking-widest transition">
                <i class="fab fa-whatsapp mr-2 text-green-500"></i> Contact Support
            </a>
        </div>
    </div>
</div>

<script>
function toggleTab(type) {
    const logForm = document.getElementById('login-form');
    const signForm = document.getElementById('signup-form');
    const btnL = document.getElementById('btn-login');
    const btnS = document.getElementById('btn-signup');

    if (type === 'login') {
        logForm.classList.remove('hidden');
        signForm.classList.add('hidden');
        btnL.className = "w-1/2 py-3 rounded-2xl text-center font-bold bg-yellow-500 text-black shadow-xl";
        btnS.className = "w-1/2 py-3 rounded-2xl text-center font-bold text-gray-500";
    } else {
        logForm.classList.add('hidden');
        signForm.classList.remove('hidden');
        btnS.className = "w-1/2 py-3 rounded-2xl text-center font-bold bg-yellow-500 text-black shadow-xl";
        btnL.className = "w-1/2 py-3 rounded-2xl text-center font-bold text-gray-500";
    }
}
</script>
</body>
</html>