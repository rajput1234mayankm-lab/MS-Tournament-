<?php
require 'common/config.php';

echo "<body style='background:#0f172a; color:#f8fafc; font-family:sans-serif; text-align:center; padding-top:50px;'>";
echo "<div style='max-width:600px; margin:auto; background:#1e293b; padding:30px; border-radius:30px; border:1px solid #334155;'>";
echo "<h1 style='color:#eab308;'>MS TOURNAMENT</h1>";
echo "<p style='color:#64748b; font-size:12px; font-weight:bold;'>DATABASE UPDATE v2.1 (Support & Security)</p>";

function addCol($conn, $table, $col, $type) {
    $check = $conn->query("SHOW COLUMNS FROM `$table` LIKE '$col'");
    if ($check->num_rows == 0) {
        $conn->query("ALTER TABLE `$table` ADD COLUMN `$col` $type");
        echo "<p style='color:#22c55e; font-size:13px; text-align:left;'>✅ Added $col to $table</p>";
    }
}

// 1. New Tables
$conn->query("CREATE TABLE IF NOT EXISTS deposits (id INT AUTO_INCREMENT PRIMARY KEY, user_id INT, amount DECIMAL(10,2), transaction_id VARCHAR(100), status ENUM('Pending', 'Completed', 'Rejected') DEFAULT 'Pending', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");
$conn->query("CREATE TABLE IF NOT EXISTS withdrawals (id INT AUTO_INCREMENT PRIMARY KEY, user_id INT, amount DECIMAL(10,2), status ENUM('Pending', 'Completed') DEFAULT 'Pending', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");
$conn->query("CREATE TABLE IF NOT EXISTS admin_settings (id INT PRIMARY KEY, upi_id VARCHAR(255), qr_code VARCHAR(255), support_link VARCHAR(255) DEFAULT 'https://wa.me/910000000000')");

// 2. Insert Default Settings
$conn->query("INSERT IGNORE INTO admin_settings (id, upi_id, qr_code) VALUES (1, 'admin@upi', 'uploads/default_qr.png')");

// 3. Columns for existing tables
addCol($conn, 'users', 'upi_id', "VARCHAR(255) DEFAULT NULL");
addCol($conn, 'users', 'status', "ENUM('Active', 'Blocked') DEFAULT 'Active'");
addCol($conn, 'tournaments', 'image', "VARCHAR(255) DEFAULT 'uploads/default.jpg'");
addCol($conn, 'tournaments', 'per_kill', "DECIMAL(10,2) DEFAULT 0.00");
addCol($conn, 'tournaments', 'rank1', "DECIMAL(10,2) DEFAULT 0.00");
addCol($conn, 'tournaments', 'rank2', "DECIMAL(10,2) DEFAULT 0.00");
addCol($conn, 'tournaments', 'rank3', "DECIMAL(10,2) DEFAULT 0.00");
addCol($conn, 'participants', 'kills', "INT DEFAULT 0");
addCol($conn, 'participants', 'rank', "INT DEFAULT 0");
addCol($conn, 'participants', 'winnings', "DECIMAL(10,2) DEFAULT 0.00");

echo "<h2 style='color:#22c55e;'>DATABASE READY!</h2>";
echo "<a href='index.php' style='background:#eab308; color:#000; padding:10px 20px; text-decoration:none; border-radius:10px; font-weight:bold;'>GO TO APP</a>";
echo "</div></body>";