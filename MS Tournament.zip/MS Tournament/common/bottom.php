</main>
    <nav class="fixed bottom-0 left-0 right-0 bg-gray-800 border-t border-gray-700 flex justify-around p-3 z-50">
        <a href="index.php" class="flex flex-col items-center text-gray-400 hover:text-yellow-500">
            <i class="fas fa-home text-xl"></i><span class="text-xs">Home</span>
        </a>
        <a href="my_tournaments.php" class="flex flex-col items-center text-gray-400 hover:text-yellow-500">
            <i class="fas fa-trophy text-xl"></i><span class="text-xs">Matches</span>
        </a>
        <a href="wallet.php" class="flex flex-col items-center text-gray-400 hover:text-yellow-500">
            <i class="fas fa-wallet text-xl"></i><span class="text-xs">Wallet</span>
        </a>
        <a href="profile.php" class="flex flex-col items-center text-gray-400 hover:text-yellow-500">
            <i class="fas fa-user text-xl"></i><span class="text-xs">Profile</span>
        </a>
    </nav>

    <script>
        // Disable Right Click
        document.addEventListener('contextmenu', event => event.preventDefault());
        // Disable text selection logic
        document.onselectstart = function() { return false; };
        // Disable zoom via gestures (already handled by meta tag, but extra layer)
        document.addEventListener('keydown', function (e) {
            if (e.ctrlKey && (e.keyCode == 61 || e.keyCode == 107 || e.keyCode == 173 || e.keyCode == 109 || e.keyCode == 187 || e.keyCode == 189)) {
                e.preventDefault();
            }
        });
    </script>
</body>
</html>