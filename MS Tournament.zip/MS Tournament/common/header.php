<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>MS TOURNAMENT</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { -webkit-tap-highlight-color: transparent; }
        .no-select { user-select: none; -webkit-user-select: none; }
    </style>
</head>
<body class="bg-gray-900 text-white no-select">
    <header class="bg-gray-800 p-4 flex justify-between items-center sticky top-0 z-50 border-b border-gray-700 shadow-lg">
        <div class="text-xl font-bold text-yellow-500">ADEPT PLAY</div>
        <?php if(isset($_SESSION['user_id'])): 
            $uid = $_SESSION['user_id'];
            $u_data = $conn->query("SELECT wallet_balance FROM users WHERE id=$uid")->fetch_assoc();
        ?>
        <div class="bg-gray-700 px-3 py-1 rounded-full flex items-center">
            <i class="fas fa-wallet text-yellow-500 mr-2"></i>
            <span class="font-bold">₹<?php echo number_format($u_data['wallet_balance'], 2); ?></span>
        </div>
        <?php endif; ?>
    </header>
    <main class="pb-24 p-4 max-w-md mx-auto">