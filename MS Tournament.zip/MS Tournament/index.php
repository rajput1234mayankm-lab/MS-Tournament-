<?php 
require 'common/config.php';
auth_user(); // Security: Bina login ke access band

$user_id = $_SESSION['user_id'];
$msg = ""; $msg_type = "yellow";

// Join Match Logic
if (isset($_POST['join_now'])) {
    $tid = (int)$_POST['tournament_id'];
    $fee = (float)$_POST['fee'];
    
    $check_joined = $conn->query("SELECT id FROM participants WHERE user_id=$user_id AND tournament_id=$tid");
    $u_data = $conn->query("SELECT wallet_balance FROM users WHERE id=$user_id")->fetch_assoc();

    if ($check_joined->num_rows > 0) {
        $msg = "⚠️ Already Joined!";
    } elseif ($u_data['wallet_balance'] < $fee) {
        $msg = "❌ Low Balance! Please add money.";
        $msg_type = "red";
    } else {
        $conn->query("UPDATE users SET wallet_balance = wallet_balance - $fee WHERE id=$user_id");
        $conn->query("INSERT INTO participants (user_id, tournament_id) VALUES ($user_id, $tid)");
        $conn->query("INSERT INTO transactions (user_id, amount, type, description) VALUES ($user_id, $fee, 'debit', 'Joined Match ID: $tid')");
        $msg = "✅ Success! Match Joined."; $msg_type = "green";
    }
}

include 'common/header.php';
?>

<div class="mb-6 flex justify-between items-center">
    <h2 class="text-2xl font-black italic uppercase tracking-tighter">Upcoming Matches</h2>
    <i class="fas fa-fire text-yellow-500"></i>
</div>

<?php if($msg) echo "<div class='bg-gray-800 border-l-4 border-$msg_type-500 p-4 rounded-xl mb-6 font-bold text-sm text-$msg_type-500'>$msg</div>"; ?>

<div class="grid gap-8 pb-10">
    <?php
    $res = $conn->query("SELECT * FROM tournaments WHERE status='Upcoming' ORDER BY match_time ASC");
    if($res->num_rows == 0) echo "<p class='text-center py-20 text-gray-600'>No matches available.</p>";

    while($row = $res->fetch_assoc()):
    ?>
    <div class="bg-gray-800 rounded-3xl overflow-hidden border border-gray-700 shadow-2xl">
        <div class="relative h-44">
            <img src="<?php echo $row['image']; ?>" class="w-full h-full object-cover">
            <div class="absolute inset-0 bg-gradient-to-t from-gray-800 to-transparent"></div>
            <span class="absolute top-3 left-3 bg-yellow-500 text-black text-[10px] font-black px-2 py-1 rounded uppercase"><?php echo $row['game_name']; ?></span>
            <h3 class="absolute bottom-3 left-4 text-xl font-black italic uppercase logo-font"><?php echo $row['title']; ?></h3>
        </div>

        <div class="p-5">
            <div class="flex items-center text-[11px] mb-4 text-gray-400 bg-gray-900 w-fit px-3 py-1 rounded-full border border-gray-700">
                <i class="far fa-clock mr-2 text-yellow-500"></i> <?php echo date('d M, h:i A', strtotime($row['match_time'])); ?>
            </div>

            <div class="grid grid-cols-2 gap-3 mb-5">
                <div class="bg-gray-900 p-3 rounded-2xl border border-gray-700 text-center">
                    <p class="text-[9px] text-gray-500 uppercase font-bold">Prize Pool</p>
                    <p class="text-lg font-black text-green-500">₹<?php echo number_format($row['prize_pool']); ?></p>
                </div>
                <div class="bg-gray-900 p-3 rounded-2xl border border-gray-700 text-center">
                    <p class="text-[9px] text-gray-500 uppercase font-bold">Entry Fee</p>
                    <p class="text-lg font-black text-yellow-500">₹<?php echo number_format($row['entry_fee']); ?></p>
                </div>
            </div>

            <div class="bg-gray-900/50 border border-gray-700 rounded-2xl p-4 mb-6 grid grid-cols-2 gap-3 text-[11px]">
                <div class="flex justify-between"> <span class="text-gray-500">Per Kill:</span> <span class="font-bold text-white">₹<?php echo $row['per_kill']; ?></span> </div>
                <div class="flex justify-between pl-3 border-l border-gray-800"> <span class="text-gray-500">Winner:</span> <span class="font-bold text-white">₹<?php echo $row['rank1']; ?></span> </div>
                <div class="flex justify-between"> <span class="text-gray-500">Rank 2:</span> <span class="font-bold text-white">₹<?php echo $row['rank2']; ?></span> </div>
                <div class="flex justify-between pl-3 border-l border-gray-800"> <span class="text-gray-500">Rank 3:</span> <span class="font-bold text-white">₹<?php echo $row['rank3']; ?></span> </div>
            </div>

            <form method="POST">
                <input type="hidden" name="tournament_id" value="<?php echo $row['id']; ?>">
                <input type="hidden" name="fee" value="<?php echo $row['entry_fee']; ?>">
                <button name="join_now" class="w-full bg-yellow-500 text-black font-black py-4 rounded-2xl shadow-lg active:scale-95 transition uppercase tracking-widest text-sm">Join Match</button>
            </form>
        </div>
    </div>
    <?php endwhile; ?>
</div>
<?php include 'common/bottom.php'; ?>