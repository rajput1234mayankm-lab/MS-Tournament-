<?php
require 'common/config.php';

// Check admin_settings row
$check = $conn->query("SELECT * FROM admin_settings WHERE id=1");
if($check->num_rows == 0) {
    $conn->query("INSERT INTO admin_settings (id, upi_id, qr_code, support_link) VALUES (1, 'admin@upi', 'uploads/default.png', 'https://wa.me/910000000000')");
    echo "✅ Admin settings row added!<br>";
}

echo "Done! Now delete this file.";
?>