<?php
require 'common/config.php';

// Table banane ki query
$sql = "CREATE TABLE IF NOT EXISTS admin_settings (
    id INT PRIMARY KEY, 
    upi_id VARCHAR(255), 
    qr_code VARCHAR(255), 
    support_link VARCHAR(255) DEFAULT 'https://wa.me/910000000000'
)";

if($conn->query($sql)) {
    // Default row insert karein agar khaali hai toh
    $conn->query("INSERT IGNORE INTO admin_settings (id, upi_id, qr_code, support_link) VALUES (1, 'admin@upi', 'uploads/default_qr.png', 'https://wa.me/910000000000')");
    echo "<h1 style='color:green; text-align:center;'>✅ Table 'admin_settings' Created & Repaired!</h1>";
    echo "<p style='text-align:center;'><a href='login.php'>Now Go to Login Page</a></p>";
} else {
    echo "Error: " . $conn->error;
}
?>