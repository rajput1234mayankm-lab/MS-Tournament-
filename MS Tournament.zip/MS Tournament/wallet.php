<?php 
require 'common/config.php';
auth_user();
$uid = $_SESSION['user_id'];
$msg = ""; $msg_type = "yellow";

$user = $conn->query("SELECT * FROM users WHERE id=$uid")->fetch_assoc();
$s = $conn->query("SELECT * FROM admin_settings WHERE id=1")->fetch_assoc();

if (isset($_POST['submit_deposit'])) {
    $a = clean($_POST['amount']); $t = clean($_POST['txn_id']);
    $conn->query("INSERT INTO deposits (user_id, amount, transaction_id) VALUES ($uid, '$a', '$t')");
    $msg = "✅ Deposit Pending! Check history."; $msg_type = "green";
}

if (isset($_POST['submit_withdrawal'])) {
    $a = (float)clean($_POST['amount']);
    if ($a < 20) { $msg = "❌ Minimum Withdrawal is ₹20!"; $msg_type = "red"; }
    elseif ($a > $user['wallet_balance']) { $msg = "❌ Insufficient Balance!"; $msg_type = "red"; }
    else {
        $conn->query("INSERT INTO withdrawals (user_id, amount) VALUES ($uid, '$a')");
        $conn->query("UPDATE users SET wallet_balance = wallet_balance - $a WHERE id=$uid");
        $conn->query("INSERT INTO transactions (user_id, amount, type, description) VALUES ($uid, $a, 'debit', 'Withdrawal Requested')");
        $msg = "✅ Pending! Sent within 8 Hours."; $msg_type = "green";
        $user = $conn->query("SELECT * FROM users WHERE id=$uid")->fetch_assoc();
    }
}
include 'common/header.php';
?>

<div class="bg-gradient-to-br from-yellow-500 to-yellow-600 p-6 rounded-[35px] text-black mb-8 shadow-xl">
    <p class="text-[10px] font-black opacity-70 uppercase tracking-widest">Available Balance</p>
    <h2 class="text-4xl font-black italic logo-font">₹<?php echo number_format($user['wallet_balance'], 2); ?></h2>
    <div class="flex gap-3 mt-6">
        <button onclick="toggleModal('depM')" class="flex-1 bg-black text-white py-3 rounded-2xl font-bold text-xs uppercase tracking-tighter">Add Money</button>
        <button onclick="toggleModal('witM')" class="flex-1 bg-white text-black py-3 rounded-2xl font-bold text-xs uppercase tracking-tighter">Withdraw</button>
    </div>
</div>

<?php if($msg) echo "<div class='bg-gray-800 p-4 rounded-xl mb-6 text-$msg_type-500 font-bold text-xs italic text-center border border-gray-700'>$msg</div>"; ?>

<h3 class="font-black italic uppercase tracking-tighter mb-4 text-gray-400">Activity History</h3>
<div class="space-y-3">
    <?php
    $h = $conn->query("(SELECT amount, status, created_at, 'Deposit' as type FROM deposits WHERE user_id=$uid) UNION (SELECT amount, status, created_at, 'Withdraw' as type FROM withdrawals WHERE user_id=$uid) ORDER BY created_at DESC");
    while($r = $h->fetch_assoc()):
        $clr = ($r['status']=='Pending') ? 'yellow' : (($r['status']=='Completed') ? 'green' : 'red');
        $st = ($r['status']=='Completed') ? 'Success' : $r['status'];
    ?>
    <div class="bg-gray-800 p-4 rounded-2xl border border-gray-700 flex justify-between items-center">
        <div>
            <p class="font-bold text-sm"><?php echo $r['type']; ?> Money</p>
            <p class="text-[10px] text-gray-500"><?php echo date('d M, h:i A', strtotime($r['created_at'])); ?></p>
        </div>
        <div class="text-right">
            <p class="font-black text-sm">₹<?php echo $r['amount']; ?></p>
            <span class="text-[9px] font-bold uppercase px-2 py-0.5 rounded bg-<?php echo $clr; ?>-500/10 text-<?php echo $clr; ?>-500 border border-<?php echo $clr; ?>-500/20"><?php echo $st; ?></span>
        </div>
    </div>
    <?php endwhile; ?>
</div>

<!-- WITHDRAW MODAL -->
<div id="witM" class="fixed inset-0 bg-black/95 z-[60] hidden flex items-center justify-center p-6">
    <div class="bg-gray-800 w-full max-w-sm rounded-[40px] p-8 border border-gray-700">
        <div class="flex justify-between items-center mb-6"> <h3 class="text-xl font-black italic text-red-500">WITHDRAWAL</h3> <button onclick="toggleModal('witM')" class="text-gray-500 text-2xl">&times;</button> </div>
        <div class="bg-blue-500/10 p-4 rounded-2xl mb-6 border border-blue-500/20 text-blue-400 text-[11px] font-bold">Withdrawal submit karne ke <span class="text-white">8 hours</span> ke andar paisa account mein aa jayega. Minimum ₹20.</div>
        <form method="POST" class="space-y-4">
            <input type="number" name="amount" min="20" placeholder="Enter Amount (Min ₹20)" class="w-full bg-gray-900 border border-gray-700 p-4 rounded-2xl text-white font-bold outline-none focus:border-red-500" required>
            <?php if(!empty($user['upi_id'])): ?> <button name="submit_withdrawal" class="w-full bg-red-600 text-white font-black py-4 rounded-2xl shadow-lg uppercase text-xs tracking-widest">Request Withdraw</button>
            <?php else: ?> <a href="profile.php" class="block w-full bg-gray-700 text-gray-400 text-center font-bold py-4 rounded-2xl text-xs">SET UPI ID IN PROFILE FIRST</a> <?php endif; ?>
        </form>
    </div>
</div>

<!-- DEPOSIT MODAL -->
<div id="depM" class="fixed inset-0 bg-black/95 z-[60] hidden flex items-center justify-center p-6">
    <div class="bg-gray-800 w-full max-w-sm rounded-[40px] p-8 border border-gray-700">
        <div class="flex justify-between items-center mb-6"> <h3 class="text-xl font-black italic text-green-500">ADD MONEY</h3> <button onclick="toggleModal('depM')" class="text-gray-500 text-2xl">&times;</button> </div>
        <div class="bg-white p-4 rounded-3xl mb-6 text-center"> <img src="<?php echo $s['qr_code']; ?>" class="w-48 h-48 mx-auto"> <p class="text-black text-xs font-bold mt-2"><?php echo $s['upi_id']; ?></p> </div>
        <form method="POST" class="space-y-4">
            <input type="number" name="amount" placeholder="Amount Paid" class="w-full bg-gray-900 border border-gray-700 p-4 rounded-2xl" required>
            <input type="text" name="txn_id" placeholder="Transaction ID / UTR" class="w-full bg-gray-900 border border-gray-700 p-4 rounded-2xl" required>
            <button name="submit_deposit" class="w-full bg-green-600 text-white font-black py-4 rounded-2xl shadow-lg uppercase text-xs tracking-widest">Submit Payment</button>
        </form>
    </div>
</div>

<script> function toggleModal(id) { document.getElementById(id).classList.toggle('hidden'); } </script>
<?php include 'common/bottom.php'; ?>