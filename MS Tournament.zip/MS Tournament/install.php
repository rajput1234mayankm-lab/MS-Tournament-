<?php
$host = '127.0.0.1';
$user = 'root';
$pass = 'root';

$conn = new mysqli($host, $user, $pass);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create Database
$conn->query("CREATE DATABASE IF NOT EXISTS ms_tournament");
$conn->select_db("ms_tournament");

// Tables
$queries = [
    "CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) UNIQUE,
        email VARCHAR(100),
        password VARCHAR(255),
        wallet_balance DECIMAL(10,2) DEFAULT 0.00,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )",
    "CREATE TABLE IF NOT EXISTS admin (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) UNIQUE,
        password VARCHAR(255)
    )",
    "CREATE TABLE IF NOT EXISTS tournaments (
        id INT AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(100),
        game_name VARCHAR(50),
        entry_fee DECIMAL(10,2),
        prize_pool DECIMAL(10,2),
        match_time DATETIME,
        room_id VARCHAR(50) DEFAULT '',
        room_password VARCHAR(50) DEFAULT '',
        status ENUM('Upcoming', 'Live', 'Completed') DEFAULT 'Upcoming',
        commission INT DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )",
    "CREATE TABLE IF NOT EXISTS participants (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT,
        tournament_id INT,
        FOREIGN KEY (user_id) REFERENCES users(id),
        FOREIGN KEY (tournament_id) REFERENCES tournaments(id)
    )",
    "CREATE TABLE IF NOT EXISTS transactions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT,
        amount DECIMAL(10,2),
        type ENUM('credit', 'debit'),
        description TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )"
];

foreach ($queries as $q) { $conn->query($q); }

// Insert default Admin
$hashed_pass = password_hash('admin123', PASSWORD_DEFAULT);
$conn->query("INSERT IGNORE INTO admin (username, password) VALUES ('admin', '$hashed_pass')");

echo "<div style='font-family:sans-serif; text-align:center; margin-top:50px;'>
        <h1>✅ Installation Successful</h1>
        <p>Database and tables created. Default Admin: <b>admin / admin123</b></p>
        <a href='login.php' style='padding:10px 20px; background:black; color:white; text-decoration:none; border-radius:5px;'>Go to Login</a>
      </div>";
?>