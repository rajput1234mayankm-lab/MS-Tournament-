<?php
require 'common/config.php';

// 1. Table banane ki query
$sql = "CREATE TABLE IF NOT EXISTS admin_settings (
    id INT PRIMARY KEY, 
    upi_id VARCHAR(255), 
    qr_code VARCHAR(255), 
    support_link VARCHAR(255) DEFAULT 'https://wa.me/910000000000'
)";

if($conn->query($sql)) {
    // 2. Default data insert karein agar empty hai toh
    $conn->query("INSERT IGNORE INTO admin_settings (id, upi_id, qr_code, support_link) VALUES (1, 'admin@upi', 'uploads/default_qr.png', 'https://wa.me/910000000000')");
    
    echo "<div style='text-align:center; padding:50px; font-family:sans-serif;'>";
    echo "<h1 style='color:green;'>✅ Database Repaired!</h1>";
    echo "<p>Ab Login page kaam karega. <a href='login.php'>Login Par Jayein</a></p>";
    echo "</div>";
} else {
    echo "Error: " . $conn->error;
}
?>