<?php 
// 1. Config file include karein (Path sahi hona chahiye)
require '../common/config.php';

// 2. Admin session check karein
if(!isset($_SESSION['admin_id'])) { 
    header("Location: login.php"); 
    exit(); 
}

// 3. Stats calculate karein
$u_count = $conn->query("SELECT COUNT(*) as t FROM users")->fetch_assoc()['t'];
$t_count = $conn->query("SELECT COUNT(*) as t FROM tournaments")->fetch_assoc()['t'];

// Total Prize Distributed (Sirf Completed matches ka)
$prize_query = $conn->query("SELECT SUM(prize_pool) as t FROM tournaments WHERE status='Completed'");
$prize_data = $prize_query->fetch_assoc();
$total_prize = $prize_data['t'] ?? 0;

// 4. Header include karein (Path: admin/common/header.php)
include 'common/header.php';
?>

<div class="mb-8">
    <h2 class="text-3xl font-black italic uppercase tracking-tighter text-white">Admin Dashboard</h2>
    <p class="text-gray-500 text-xs">Overview of MS Tournament Platform</p>
</div>

<!-- Stats Cards Grid -->
<div class="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-10">
    
    <!-- Card 1: Users -->
    <div class="bg-gray-800 p-6 rounded-3xl border border-gray-700 shadow-xl">
        <div class="flex items-center justify-between mb-4">
            <i class="fas fa-users text-blue-500 text-xl"></i>
            <span class="text-[10px] bg-blue-500/10 text-blue-500 px-2 py-1 rounded-full font-bold uppercase">Total</span>
        </div>
        <p class="text-gray-400 text-xs font-bold uppercase tracking-widest">Registered Users</p>
        <p class="text-4xl font-black text-white mt-1"><?php echo $u_count; ?></p>
    </div>

    <!-- Card 2: Tournaments -->
    <div class="bg-gray-800 p-6 rounded-3xl border border-gray-700 shadow-xl">
        <div class="flex items-center justify-between mb-4">
            <i class="fas fa-gamepad text-purple-500 text-xl"></i>
            <span class="text-[10px] bg-purple-500/10 text-purple-500 px-2 py-1 rounded-full font-bold uppercase">Matches</span>
        </div>
        <p class="text-gray-400 text-xs font-bold uppercase tracking-widest">Total Events</p>
        <p class="text-4xl font-black text-white mt-1"><?php echo $t_count; ?></p>
    </div>

    <!-- Card 3: Prize -->
    <div class="bg-gray-800 p-6 rounded-3xl border border-gray-700 shadow-xl">
        <div class="flex items-center justify-between mb-4">
            <i class="fas fa-trophy text-green-500 text-xl"></i>
            <span class="text-[10px] bg-green-500/10 text-green-500 px-2 py-1 rounded-full font-bold uppercase">Paid</span>
        </div>
        <p class="text-gray-400 text-xs font-bold uppercase tracking-widest">Prize Distributed</p>
        <p class="text-4xl font-black text-white mt-1">₹<?php echo number_format($total_prize); ?></p>
    </div>

</div>

<!-- Quick Actions -->
<div class="bg-gray-800 p-8 rounded-3xl border border-gray-700 shadow-2xl flex flex-col md:flex-row items-center justify-between">
    <div>
        <h3 class="text-xl font-bold mb-1">Manage Your Matches</h3>
        <p class="text-gray-400 text-sm">Create, edit or declare results for tournaments.</p>
    </div>
    <a href="tournament.php" class="mt-6 md:mt-0 bg-yellow-500 text-black font-black px-10 py-4 rounded-2xl shadow-lg hover:bg-yellow-400 transition transform active:scale-95 uppercase tracking-widest text-sm">
        Create New Tournament
    </a>
</div>

<?php 
// 5. Bottom include karein (Path: admin/common/bottom.php)
include 'common/bottom.php'; 
?>