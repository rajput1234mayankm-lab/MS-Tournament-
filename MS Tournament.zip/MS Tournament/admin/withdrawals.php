<?php 
require '../common/config.php';

// Admin Auth Check
if(!isset($_SESSION['admin_id'])) { header("Location: login.php"); exit(); }

$msg = "";

// ---------------------------------------------------------
// MARK AS PAID LOGIC
// ---------------------------------------------------------
if (isset($_GET['complete'])) {
    $id = (int)$_GET['complete'];
    $with = $conn->query("SELECT * FROM withdrawals WHERE id=$id AND status='Pending'")->fetch_assoc();
    if ($with) {
        $conn->query("UPDATE withdrawals SET status='Completed' WHERE id=$id");
        $msg = "✅ Withdrawal marked as Completed!";
    }
}

include 'common/header.php';
?>

<div class="mb-6">
    <h2 class="text-2xl font-black italic uppercase text-red-500 tracking-tighter">Withdrawal Requests</h2>
    <p class="text-gray-500 text-[10px] uppercase font-bold tracking-widest mt-1">Manually pay to User UPI first, then click button</p>
</div>

<?php if($msg) echo "<div class='bg-gray-800 border-l-4 border-green-500 p-4 rounded-xl mb-6 text-green-500 font-bold text-sm shadow-lg'>$msg</div>"; ?>

<div class="bg-gray-800 rounded-3xl overflow-hidden border border-gray-700 shadow-2xl overflow-x-auto">
    <table class="w-full text-left">
        <thead class="bg-gray-700 text-gray-300 text-[10px] uppercase font-black">
            <tr>
                <th class="p-4">User</th>
                <th class="p-4">Amount</th>
                <th class="p-4">User UPI ID</th>
                <th class="p-4">Action</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-gray-700">
            <?php
            // Error Handling: Query check
            $res = $conn->query("SELECT w.*, u.username, u.upi_id FROM withdrawals w JOIN users u ON w.user_id = u.id WHERE w.status='Pending' ORDER BY w.id DESC");
            
            if($res && $res->num_rows > 0):
                while($row = $res->fetch_assoc()):
            ?>
            <tr class="hover:bg-gray-750 transition">
                <td class="p-4 font-bold text-white"><?php echo $row['username']; ?></td>
                <td class="p-4 font-black text-red-500">₹<?php echo number_format($row['amount'], 2); ?></td>
                <td class="p-4">
                    <div class="bg-gray-900 px-3 py-2 rounded-xl border border-gray-700 text-blue-400 font-mono text-xs break-all">
                        <?php echo $row['upi_id']; ?>
                    </div>
                </td>
                <td class="p-4">
                    <a href="?complete=<?php echo $row['id']; ?>" 
                       onclick="return confirm('Money sent to <?php echo $row['upi_id']; ?>?')" 
                       class="bg-blue-600 hover:bg-blue-500 text-white px-3 py-2 rounded-xl text-[10px] font-black uppercase shadow-lg block text-center transition">
                        Mark as Paid
                    </a>
                </td>
            </tr>
            <?php 
                endwhile;
            else:
                echo "<tr><td colspan='4' class='p-10 text-center text-gray-600 italic font-bold'>No pending withdrawals found.</td></tr>";
            endif;
            ?>
        </tbody>
    </table>
</div>

<?php include 'common/bottom.php'; ?>