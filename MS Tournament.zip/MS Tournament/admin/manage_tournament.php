<?php 
require '../common/config.php';

// Admin Auth Check
if(!isset($_SESSION['admin_id'])) { 
    header("Location: login.php"); 
    exit(); 
}

if(!isset($_GET['id'])) {
    header("Location: tournament.php");
    exit();
}

$tid = (int)$_GET['id'];
$msg = "";

// Tournament ki details fetch karein (Prizes check karne ke liye)
$t_query = $conn->query("SELECT * FROM tournaments WHERE id=$tid");
if($t_query->num_rows == 0) { echo "Tournament not found!"; exit; }
$t = $t_query->fetch_assoc();

// ---------------------------------------------------------
// RESULT DECLARE & PRIZE DISTRIBUTION LOGIC
// ---------------------------------------------------------
if(isset($_POST['declare_result'])) {
    $p_ids = $_POST['p_id']; // Participants Table IDs
    $u_ids = $_POST['u_id']; // User IDs
    $kills = $_POST['kills'];
    $ranks = $_POST['ranks'];

    foreach($p_ids as $key => $pid) {
        $k = (int)$kills[$key];
        $r = (int)$ranks[$key];
        $uid = (int)$u_ids[$key];

        // 1. Calculate Prize
        // Formula: (Kills * Per Kill Rate) + Rank Prize
        $win_amt = ($k * $t['per_kill']);
        
        if($r == 1) $win_amt += $t['rank1'];
        elseif($r == 2) $win_amt += $t['rank2'];
        elseif($r == 3) $win_amt += $t['rank3'];

        // 2. Update Participants Table (Kills, Rank, Winnings)
        $conn->query("UPDATE participants SET kills=$k, rank=$r, winnings=$win_amt WHERE id=$pid");

        // 3. Add Winnings to User Wallet
        if($win_amt > 0) {
            $conn->query("UPDATE users SET wallet_balance = wallet_balance + $win_amt WHERE id=$uid");
            
            // 4. Record Transaction
            $desc = "Won in {$t['title']} (Kills: $k, Rank: $r)";
            $conn->query("INSERT INTO transactions (user_id, amount, type, description) VALUES ($uid, $win_amt, 'credit', '$desc')");
        }
    }

    // 5. Mark Tournament as Completed
    $conn->query("UPDATE tournaments SET status='Completed' WHERE id=$tid");
    
    $msg = "✅ Result Declared & Prizes Distributed Successfully!";
}

// Room ID/Pass Update Logic
if(isset($_POST['update_room'])) {
    $rid = clean($_POST['room_id']);
    $rpass = clean($_POST['room_pass']);
    $status = clean($_POST['status']);
    
    $conn->query("UPDATE tournaments SET room_id='$rid', room_password='$rpass', status='$status' WHERE id=$tid");
    $msg = "✅ Room Details & Status Updated!";
    // Refresh data
    $t = $conn->query("SELECT * FROM tournaments WHERE id=$tid")->fetch_assoc();
}

include 'common/header.php';
?>

<div class="max-w-5xl">
    <div class="flex items-center justify-between mb-8">
        <div>
            <h2 class="text-2xl font-black italic uppercase text-white logo-font tracking-tighter">Manage Match</h2>
            <p class="text-gray-500 text-xs"><?php echo $t['title']; ?> (<?php echo $t['game_name']; ?>)</p>
        </div>
        <a href="tournament.php" class="text-gray-400 hover:text-white text-sm"><i class="fas fa-arrow-left mr-1"></i> Back</a>
    </div>

    <?php if($msg) echo "<div class='bg-green-600 text-white p-4 rounded-2xl mb-8 font-bold shadow-lg animate-pulse'>$msg</div>"; ?>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        <!-- LEFT: ROOM DETAILS & STATUS -->
        <div class="lg:col-span-1 space-y-6">
            <div class="bg-gray-800 p-6 rounded-3xl border border-gray-700 shadow-xl">
                <h3 class="text-yellow-500 font-bold mb-4 text-xs uppercase tracking-widest">Room Info & Status</h3>
                <form method="POST" class="space-y-4">
                    <div>
                        <label class="text-[10px] text-gray-500 uppercase ml-1">Room ID</label>
                        <input type="text" name="room_id" value="<?php echo $t['room_id']; ?>" class="w-full bg-gray-900 border border-gray-700 p-3 rounded-xl outline-none focus:border-yellow-500">
                    </div>
                    <div>
                        <label class="text-[10px] text-gray-500 uppercase ml-1">Room Password</label>
                        <input type="text" name="room_pass" value="<?php echo $t['room_password']; ?>" class="w-full bg-gray-900 border border-gray-700 p-3 rounded-xl outline-none focus:border-yellow-500">
                    </div>
                    <div>
                        <label class="text-[10px] text-gray-500 uppercase ml-1">Match Status</label>
                        <select name="status" class="w-full bg-gray-900 border border-gray-700 p-3 rounded-xl outline-none text-white">
                            <option value="Upcoming" <?php if($t['status']=='Upcoming') echo 'selected'; ?>>Upcoming</option>
                            <option value="Live" <?php if($t['status']=='Live') echo 'selected'; ?>>Live (Room Ready)</option>
                            <option value="Completed" <?php if($t['status']=='Completed') echo 'selected'; ?>>Completed</option>
                        </select>
                    </div>
                    <button name="update_room" class="w-full bg-blue-600 text-white font-bold py-3 rounded-xl shadow-lg active:scale-95 transition uppercase text-xs">Update Room Details</button>
                </form>
            </div>

            <!-- PRIZE REFERENCE -->
            <div class="bg-gray-800 p-6 rounded-3xl border border-gray-700 shadow-xl">
                <h3 class="text-gray-500 font-bold mb-4 text-xs uppercase tracking-widest">Prize Reference</h3>
                <div class="space-y-2 text-sm">
                    <div class="flex justify-between"><span>Per Kill:</span> <span class="text-green-500 font-bold">₹<?php echo $t['per_kill']; ?></span></div>
                    <div class="flex justify-between"><span>Winner (#1):</span> <span class="text-yellow-500 font-bold">₹<?php echo $t['rank1']; ?></span></div>
                    <div class="flex justify-between"><span>Rank #2:</span> <span class="text-gray-300 font-bold">₹<?php echo $t['rank2']; ?></span></div>
                    <div class="flex justify-between"><span>Rank #3:</span> <span class="text-orange-400 font-bold">₹<?php echo $t['rank3']; ?></span></div>
                </div>
            </div>
        </div>

        <!-- RIGHT: PARTICIPANTS & RESULT DECLARATION -->
        <div class="lg:col-span-2">
            <div class="bg-gray-800 rounded-3xl border border-gray-700 shadow-xl overflow-hidden">
                <div class="p-6 border-b border-gray-700 flex justify-between items-center">
                    <h3 class="text-white font-bold text-sm uppercase tracking-widest">Participants List</h3>
                    <span class="bg-gray-700 text-[10px] px-2 py-1 rounded-full text-gray-400 uppercase font-bold">Total: <?php echo $conn->query("SELECT id FROM participants WHERE tournament_id=$tid")->num_rows; ?></span>
                </div>
                
                <form method="POST">
                    <div class="overflow-x-auto">
                        <table class="w-full text-left text-sm">
                            <thead class="bg-gray-900/50 text-gray-500 uppercase text-[10px] font-black">
                                <tr>
                                    <th class="p-4">Player Name</th>
                                    <th class="p-4 text-center">Kills</th>
                                    <th class="p-4 text-center">Rank</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-700">
                                <?php 
                                $res = $conn->query("SELECT p.*, u.username FROM participants p JOIN users u ON p.user_id = u.id WHERE p.tournament_id = $tid");
                                if($res->num_rows == 0) {
                                    echo "<tr><td colspan='3' class='p-10 text-center text-gray-600 italic'>No players joined yet.</td></tr>";
                                }
                                while($row = $res->fetch_assoc()): 
                                ?>
                                <tr class="hover:bg-gray-750 transition">
                                    <td class="p-4">
                                        <div class="font-bold text-white"><?php echo $row['username']; ?></div>
                                        <input type="hidden" name="p_id[]" value="<?php echo $row['id']; ?>">
                                        <input type="hidden" name="u_id[]" value="<?php echo $row['user_id']; ?>">
                                    </td>
                                    <td class="p-4 text-center">
                                        <input type="number" name="kills[]" value="<?php echo $row['kills']; ?>" min="0" 
                                               class="w-20 bg-gray-900 border border-gray-600 p-2 rounded-xl text-center text-green-500 font-bold outline-none focus:border-green-500">
                                    </td>
                                    <td class="p-4 text-center">
                                        <input type="number" name="ranks[]" value="<?php echo $row['rank']; ?>" min="0" max="100" 
                                               class="w-20 bg-gray-900 border border-gray-600 p-2 rounded-xl text-center text-yellow-500 font-bold outline-none focus:border-yellow-500">
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>

                    <?php if($t['status'] != 'Completed'): ?>
                    <div class="p-6 bg-gray-900/30">
                        <button name="declare_result" onclick="return confirm('Attention: Prizes will be distributed instantly to all winners. Confirm Result?')" 
                                class="w-full bg-green-600 hover:bg-green-500 text-white font-black py-4 rounded-2xl shadow-lg transition transform active:scale-95 uppercase tracking-widest text-sm">
                            <i class="fas fa-check-circle mr-2"></i> Declare Result & Pay Winners
                        </button>
                    </div>
                    <?php else: ?>
                    <div class="p-6 bg-gray-900/30 text-center">
                        <span class="text-gray-500 font-bold italic uppercase text-xs tracking-widest">Result Already Declared for this Match</span>
                    </div>
                    <?php endif; ?>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include 'common/bottom.php'; ?>