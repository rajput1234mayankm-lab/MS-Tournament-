<?php 
require '../common/config.php';

// Admin Auth Check
if(!isset($_SESSION['admin_id'])) { header("Location: login.php"); exit(); }

$msg = "";

// ---------------------------------------------------------
// APPROVE / REJECT LOGIC
// ---------------------------------------------------------
if (isset($_GET['approve'])) {
    $id = (int)$_GET['approve'];
    $dep = $conn->query("SELECT * FROM deposits WHERE id=$id AND status='Pending'")->fetch_assoc();
    if ($dep) {
        $uid = $dep['user_id'];
        $amt = $dep['amount'];
        // Wallet update
        $conn->query("UPDATE users SET wallet_balance = wallet_balance + $amt WHERE id=$uid");
        // Status update
        $conn->query("UPDATE deposits SET status='Completed' WHERE id=$id");
        // Transaction History
        $conn->query("INSERT INTO transactions (user_id, amount, type, description) VALUES ($uid, $amt, 'credit', 'Deposit Approved')");
        $msg = "✅ Deposit Approved!";
    }
}

if (isset($_GET['reject'])) {
    $id = (int)$_GET['reject'];
    $conn->query("UPDATE deposits SET status='Rejected' WHERE id=$id");
    $msg = "❌ Deposit Rejected!";
}

include 'common/header.php';
?>

<div class="mb-6">
    <h2 class="text-2xl font-black italic uppercase text-green-500 tracking-tighter">Deposit Requests</h2>
    <p class="text-gray-500 text-[10px] uppercase font-bold tracking-widest mt-1">Check Transaction ID in your bank app before approving</p>
</div>

<?php if($msg) echo "<div class='bg-gray-800 border-l-4 border-yellow-500 p-4 rounded-xl mb-6 text-yellow-500 font-bold text-sm shadow-lg'>$msg</div>"; ?>

<div class="bg-gray-800 rounded-3xl overflow-hidden border border-gray-700 shadow-2xl overflow-x-auto">
    <table class="w-full text-left">
        <thead class="bg-gray-700 text-gray-300 text-[10px] uppercase font-black">
            <tr>
                <th class="p-4">User</th>
                <th class="p-4">Amount</th>
                <th class="p-4">Txn ID / UTR</th>
                <th class="p-4">Action</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-gray-700">
            <?php
            // Error Handling: Query check
            $res = $conn->query("SELECT d.*, u.username FROM deposits d JOIN users u ON d.user_id = u.id WHERE d.status='Pending' ORDER BY d.id DESC");
            
            if($res && $res->num_rows > 0):
                while($row = $res->fetch_assoc()):
            ?>
            <tr class="hover:bg-gray-750 transition">
                <td class="p-4 font-bold text-white"><?php echo $row['username']; ?></td>
                <td class="p-4 font-black text-green-500">₹<?php echo number_format($row['amount'], 2); ?></td>
                <td class="p-4">
                    <span class="bg-gray-900 px-3 py-1 rounded-lg border border-gray-700 text-yellow-500 font-mono text-xs">
                        <?php echo $row['transaction_id']; ?>
                    </span>
                </td>
                <td class="p-4 flex space-x-2">
                    <a href="?approve=<?php echo $row['id']; ?>" onclick="return confirm('Approve this?')" class="bg-green-600 p-2 rounded-xl text-white text-[10px] font-bold uppercase shadow-lg">Approve</a>
                    <a href="?reject=<?php echo $row['id']; ?>" onclick="return confirm('Reject this?')" class="bg-red-600 p-2 rounded-xl text-white text-[10px] font-bold uppercase shadow-lg">Reject</a>
                </td>
            </tr>
            <?php 
                endwhile;
            else:
                echo "<tr><td colspan='4' class='p-10 text-center text-gray-600 italic font-bold'>No pending deposits found.</td></tr>";
            endif;
            ?>
        </tbody>
    </table>
</div>

<?php include 'common/bottom.php'; ?>