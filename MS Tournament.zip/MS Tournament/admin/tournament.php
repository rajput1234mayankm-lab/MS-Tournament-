<?php 
require '../common/config.php';
if(!isset($_SESSION['admin_id'])) { header("Location: login.php"); exit(); }

$msg = "";

// 1. DELETE LOGIC
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    // Pehle image ka naam nikal lo taaki folder se delete kar sakein (Optional but good)
    $res = $conn->query("SELECT image FROM tournaments WHERE id=$id");
    $row = $res->fetch_assoc();
    if($row && $row['image'] != 'uploads/default.jpg') {
        if(file_exists("../".$row['image'])) unlink("../".$row['image']);
    }
    
    // Database se delete karein
    $conn->query("DELETE FROM tournaments WHERE id=$id");
    $conn->query("DELETE FROM participants WHERE tournament_id=$id"); // Cascade delete
    $msg = "❌ Tournament Deleted!";
}

// 2. CREATE LOGIC (Pehle wala hi hai)
if(isset($_POST['add'])) {
    $title = clean($_POST['title']); $game = clean($_POST['game']);
    $fee = $_POST['fee']; $prize = $_POST['prize']; $time = $_POST['time'];
    $pk = $_POST['per_kill']; $r1 = $_POST['rank1']; $r2 = $_POST['rank2']; $r3 = $_POST['rank3'];
    
    $img_path = "uploads/default.jpg";
    if(!empty($_FILES['img']['name'])) {
        $path = "uploads/tour_".time().".jpg";
        move_uploaded_file($_FILES['img']['tmp_name'], "../".$path);
        $img_path = $path;
    }
    $sql = "INSERT INTO tournaments (title, game_name, entry_fee, prize_pool, match_time, image, per_kill, rank1, rank2, rank3) 
            VALUES ('$title', '$game', '$fee', '$prize', '$time', '$img_path', '$pk', '$r1', '$r2', '$r3')";
    if($conn->query($sql)) { $msg = "✅ Match Created!"; }
}

include 'common/header.php';
?>

<div class="max-w-5xl">
    <h2 class="text-2xl font-black italic uppercase mb-6 text-white">Manage Tournaments</h2>

    <?php if($msg) echo "<div class='bg-gray-800 border-l-4 border-yellow-500 text-yellow-500 p-4 rounded-xl mb-6 font-bold shadow-lg'>$msg</div>"; ?>

    <!-- Form (Aapke screenshot wala hi layout) -->
    <form method="POST" enctype="multipart/form-data" class="bg-gray-800 p-6 rounded-3xl border border-gray-700 shadow-xl mb-10">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
             <input type="text" name="title" placeholder="Match Title" class="bg-gray-900 p-3 rounded-xl border border-gray-700 text-white outline-none" required>
             <input type="text" name="game" placeholder="Game Name" class="bg-gray-900 p-3 rounded-xl border border-gray-700 text-white outline-none" required>
             <input type="number" name="fee" placeholder="Entry Fee (₹)" class="bg-gray-900 p-3 rounded-xl border border-gray-700 text-white outline-none" required>
             <input type="number" name="prize" placeholder="Total Prize Pool (₹)" class="bg-gray-900 p-3 rounded-xl border border-gray-700 text-white outline-none" required>
             <input type="datetime-local" name="time" class="bg-gray-900 p-3 rounded-xl border border-gray-700 text-gray-400 outline-none" required>
             <input type="file" name="img" class="bg-gray-900 p-2 rounded-xl text-xs text-gray-500" required>
             
             <input type="number" name="per_kill" placeholder="Per Kill" class="bg-gray-900 p-3 rounded-xl border border-gray-700 text-white" value="0">
             <input type="number" name="rank1" placeholder="Rank 1" class="bg-gray-900 p-3 rounded-xl border border-gray-700 text-white" value="0">
             <input type="number" name="rank2" placeholder="Rank 2" class="bg-gray-900 p-3 rounded-xl border border-gray-700 text-white" value="0">
             <input type="number" name="rank3" placeholder="Rank 3" class="bg-gray-900 p-3 rounded-xl border border-gray-700 text-white" value="0">

             <button name="add" class="md:col-span-2 bg-yellow-500 text-black font-black py-4 rounded-2xl shadow-lg mt-4 uppercase">CREATE MATCH NOW</button>
        </div>
    </form>

    <!-- LIST TABLE WITH EDIT/DELETE -->
    <div class="bg-gray-800 rounded-3xl overflow-hidden border border-gray-700 shadow-2xl">
        <table class="w-full text-left text-sm">
            <thead class="bg-gray-700 text-gray-300 text-[10px] uppercase font-black">
                <tr>
                    <th class="p-4">Match</th>
                    <th class="p-4">Entry/Prize</th>
                    <th class="p-4">Actions</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-700">
                <?php $res = $conn->query("SELECT * FROM tournaments ORDER BY id DESC");
                while($row = $res->fetch_assoc()): ?>
                <tr class="hover:bg-gray-750 transition">
                    <td class="p-4 flex items-center">
                        <img src="../<?php echo $row['image']; ?>" class="w-10 h-10 rounded-lg object-cover mr-3 border border-gray-600">
                        <div>
                            <p class="font-bold text-white"><?php echo $row['title']; ?></p>
                            <p class="text-[10px] text-gray-500"><?php echo $row['status']; ?></p>
                        </div>
                    </td>
                    <td class="p-4">
                        <p class="text-xs text-green-500 font-bold">P: ₹<?php echo $row['prize_pool']; ?></p>
                        <p class="text-xs text-yellow-500 font-bold">F: ₹<?php echo $row['entry_fee']; ?></p>
                    </td>
                    <td class="p-4">
                        <div class="flex space-x-2">
                            <!-- EDIT BUTTON -->
                            <a href="edit_tournament.php?id=<?php echo $row['id']; ?>" class="bg-blue-600 p-2 rounded-lg text-white hover:bg-blue-500 transition shadow-lg">
                                <i class="fas fa-edit text-xs"></i>
                            </a>
                            <!-- MANAGE BUTTON -->
                            <a href="manage_tournament.php?id=<?php echo $row['id']; ?>" class="bg-green-600 p-2 rounded-lg text-white hover:bg-green-500 transition shadow-lg">
                                <i class="fas fa-cog text-xs"></i>
                            </a>
                            <!-- DELETE BUTTON -->
                            <a href="?delete=<?php echo $row['id']; ?>" onclick="return confirm('Pakka delete karna hai?')" class="bg-red-600 p-2 rounded-lg text-white hover:bg-red-500 transition shadow-lg">
                                <i class="fas fa-trash text-xs"></i>
                            </a>
                        </div>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include 'common/bottom.php'; ?>