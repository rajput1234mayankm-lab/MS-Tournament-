<?php 
require '../common/config.php';
// Admin Auth Check
if(!isset($_SESSION['admin_id'])) { header("Location: login.php"); exit(); }

$msg = "";

// 1. WALLET UPDATE LOGIC (Add / Deduct)
if (isset($_POST['update_wallet'])) {
    $uid = (int)$_POST['user_id'];
    $amt = (float)$_POST['amount'];
    $action = $_POST['action']; // 'add' ya 'deduct'
    
    if($action == 'add') {
        $conn->query("UPDATE users SET wallet_balance = wallet_balance + $amt WHERE id=$uid");
        $conn->query("INSERT INTO transactions (user_id, amount, type, description) VALUES ($uid, $amt, 'credit', 'Added by Admin')");
        $msg = "✅ Amount Added Successfully!";
    } else {
        $conn->query("UPDATE users SET wallet_balance = wallet_balance - $amt WHERE id=$uid");
        $conn->query("INSERT INTO transactions (user_id, amount, type, description) VALUES ($uid, $amt, 'debit', 'Deducted by Admin')");
        $msg = "✅ Amount Deducted Successfully!";
    }
}

// 2. BLOCK / UNBLOCK LOGIC
if (isset($_GET['toggle_block'])) {
    $uid = (int)$_GET['toggle_block'];
    $curr_status = $_GET['status'];
    $new_status = ($curr_status == 'Active') ? 'Blocked' : 'Active';
    
    $conn->query("UPDATE users SET status='$new_status' WHERE id=$uid");
    $msg = "✅ User status updated to $new_status!";
}

include 'common/header.php';
?>

<div class="mb-6">
    <h2 class="text-2xl font-black italic uppercase text-blue-500 tracking-tighter">Registered Users</h2>
    <p class="text-gray-500 text-xs mt-1 uppercase font-bold tracking-widest">Manage User Accounts & Wallets</p>
</div>

<?php if($msg): ?>
    <div class="bg-gray-800 border-l-4 border-blue-500 text-blue-500 p-4 rounded-xl mb-6 font-bold text-sm shadow-lg animate-pulse">
        <?php echo $msg; ?>
    </div>
<?php endif; ?>

<div class="bg-gray-800 rounded-3xl overflow-hidden border border-gray-700 shadow-2xl overflow-x-auto">
    <table class="w-full text-left">
        <thead class="bg-gray-700 text-gray-300 text-[10px] uppercase font-black">
            <tr>
                <th class="p-4">User Details</th>
                <th class="p-4">Wallet Balance</th>
                <th class="p-4">Status</th>
                <th class="p-4 text-center">Manage Wallet</th>
                <th class="p-4">Account Action</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-gray-700">
            <?php
            $res = $conn->query("SELECT * FROM users ORDER BY id DESC");
            while($row = $res->fetch_assoc()):
                $status_color = ($row['status'] == 'Active') ? 'green' : 'red';
            ?>
            <tr class="hover:bg-gray-750 transition">
                <td class="p-4">
                    <div class="font-bold text-white"><?php echo $row['username']; ?></div>
                    <div class="text-[10px] text-gray-500 truncate w-32"><?php echo $row['email']; ?></div>
                </td>
                <td class="p-4">
                    <span class="font-black text-green-500 text-lg">₹<?php echo number_format($row['wallet_balance'], 2); ?></span>
                </td>
                <td class="p-4 text-xs font-bold uppercase">
                    <span class="text-<?php echo $status_color; ?>-500 bg-<?php echo $status_color; ?>-500/10 px-2 py-1 rounded-full border border-<?php echo $status_color; ?>-500/20">
                        <?php echo $row['status']; ?>
                    </span>
                </td>
                
                <!-- WALLET CONTROL FORM -->
                <td class="p-4">
                    <form method="POST" class="flex items-center space-x-1">
                        <input type="hidden" name="user_id" value="<?php echo $row['id']; ?>">
                        <input type="number" name="amount" placeholder="Amt" class="w-16 bg-gray-900 border border-gray-700 p-2 rounded-lg text-xs outline-none focus:border-blue-500" required>
                        <select name="action" class="bg-gray-900 border border-gray-700 p-2 rounded-lg text-[10px] outline-none">
                            <option value="add">ADD</option>
                            <option value="deduct">CUT</option>
                        </select>
                        <button name="update_wallet" class="bg-blue-600 hover:bg-blue-500 p-2 rounded-lg transition">
                            <i class="fas fa-check text-xs"></i>
                        </button>
                    </form>
                </td>

                <td class="p-4">
                    <a href="?toggle_block=<?php echo $row['id']; ?>&status=<?php echo $row['status']; ?>" 
                       onclick="return confirm('Change status for <?php echo $row['username']; ?>?')"
                       class="text-[10px] font-black uppercase tracking-tighter px-3 py-2 rounded-xl border <?php echo ($row['status'] == 'Active') ? 'border-red-900 text-red-500 hover:bg-red-500 hover:text-white' : 'border-green-900 text-green-500 hover:bg-green-500 hover:text-white'; ?> transition block text-center">
                        <?php echo ($row['status'] == 'Active') ? 'Block User' : 'Unblock User'; ?>
                    </a>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<?php include 'common/bottom.php'; ?>