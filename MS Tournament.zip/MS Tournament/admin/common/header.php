<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MS Tournament - Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@700&display=swap');
        .logo-font { font-family: 'Orbitron', sans-serif; }
    </style>
</head>
<body class="bg-gray-900 text-white min-h-screen">
    <!-- Main Flex Container -->
    <div class="flex flex-col md:flex-row min-h-screen">
        
        <!-- Sidebar -->
        <div class="w-full md:w-64 bg-gray-800 border-b md:border-r border-gray-700 p-6 flex-shrink-0">
            <h1 class="text-xl font-black text-yellow-500 logo-font italic tracking-tighter mb-1">MS TOURNAMENT</h1>
            <p class="text-[10px] text-gray-500 font-bold uppercase tracking-widest mb-8 border-b border-gray-700 pb-2">Admin Control</p>
            
            <nav class="space-y-1">
                <a href="index.php" class="flex items-center p-3 rounded-xl hover:bg-gray-700 transition text-sm">
                    <i class="fas fa-th-large w-8 text-blue-400"></i> Dashboard
                </a>
                <a href="tournament.php" class="flex items-center p-3 rounded-xl hover:bg-gray-700 transition text-sm">
                    <i class="fas fa-gamepad w-8 text-purple-400"></i> Tournaments
                </a>

                <div class="pt-4 pb-1 px-3 text-[10px] font-bold text-gray-500 uppercase tracking-widest">Payments</div>
                <a href="deposits.php" class="flex items-center p-3 rounded-xl hover:bg-gray-700 transition text-sm font-bold">
                    <i class="fas fa-arrow-circle-down w-8 text-green-500"></i> Deposits
                </a>
                <a href="withdrawals.php" class="flex items-center p-3 rounded-xl hover:bg-gray-700 transition text-sm font-bold">
                    <i class="fas fa-university w-8 text-red-500"></i> Withdrawals
                </a>

                <div class="pt-4 pb-1 px-3 text-[10px] font-bold text-gray-500 uppercase tracking-widest">System</div>
                <a href="user.php" class="flex items-center p-3 rounded-xl hover:bg-gray-700 transition text-sm">
                    <i class="fas fa-users w-8 text-indigo-400"></i> Users
                </a>
                <a href="setting.php" class="flex items-center p-3 rounded-xl hover:bg-gray-700 transition text-sm">
                    <i class="fas fa-cog w-8 text-gray-400"></i> Settings
                </a>
                <a href="../login.php" class="flex items-center p-3 rounded-xl text-red-400 hover:bg-red-900/20 mt-10 transition text-sm">
                    <i class="fas fa-power-off w-8"></i> Logout
                </a>
            </nav>
        </div>
        
        <!-- Main Content Area -->
        <main class="flex-1 p-6 bg-gray-900">