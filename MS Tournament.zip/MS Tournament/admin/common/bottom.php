</main> <!-- Content Area Band -->
    </div> <!-- Sidebar + Main Flex Band -->

    <script>
        // Admin security: Right click band
        document.addEventListener('contextmenu', e => e.preventDefault());
        document.onselectstart = () => false;
    </script>
</body>
</html>