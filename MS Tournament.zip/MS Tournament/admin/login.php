<?php 
require '../common/config.php';
$msg = "";

if (isset($_POST['admin_login'])) {
    $user = clean($_POST['username']);
    $pass = $_POST['password'];
    
    $res = $conn->query("SELECT * FROM admin WHERE username='$user'");
    if ($res->num_rows > 0) {
        $row = $res->fetch_assoc();
        if (password_verify($pass, $row['password'])) {
            $_SESSION['admin_id'] = $row['id'];
            $_SESSION['admin_user'] = $row['username'];
            header("Location: index.php");
            exit();
        } else { $msg = "Invalid Password!"; }
    } else { $msg = "Admin not found!"; }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - MS TOURNAMENT</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-900 text-white flex items-center justify-center min-h-screen p-6">
    <div class="w-full max-w-sm bg-gray-800 p-8 rounded-3xl shadow-2xl border border-gray-700">
        <div class="text-center mb-8">
            <h1 class="text-3xl font-black text-yellow-500">ADMIN PANEL</h1>
            <p class="text-gray-400 text-sm">Control center access</p>
        </div>

        <?php if($msg) echo "<p class='text-red-500 text-center mb-4 font-bold'>$msg</p>"; ?>

        <form method="POST" class="space-y-4">
            <div class="space-y-1">
                <label class="text-xs text-gray-400 ml-1 uppercase font-bold">Username</label>
                <input type="text" name="username" class="w-full bg-gray-900 border border-gray-700 p-3 rounded-xl focus:outline-none focus:border-yellow-500 transition" required>
            </div>
            <div class="space-y-1">
                <label class="text-xs text-gray-400 ml-1 uppercase font-bold">Password</label>
                <input type="password" name="password" class="w-full bg-gray-900 border border-gray-700 p-3 rounded-xl focus:outline-none focus:border-yellow-500 transition" required>
            </div>
            <button type="submit" name="admin_login" class="w-full bg-yellow-500 text-black font-black py-4 rounded-xl hover:bg-yellow-400 transition transform active:scale-95">
                SECURE LOGIN
            </button>
        </form>
        <div class="mt-6 text-center">
            <a href="../login.php" class="text-xs text-gray-500 hover:text-yellow-500">Return to User Site</a>
        </div>
    </div>
</body>
</html>