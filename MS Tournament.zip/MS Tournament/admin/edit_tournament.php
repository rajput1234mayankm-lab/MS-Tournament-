<?php 
require '../common/config.php';
if(!isset($_SESSION['admin_id'])) { header("Location: login.php"); exit(); }

$id = (int)$_GET['id'];
$msg = "";

// 1. UPDATE LOGIC
if(isset($_POST['update'])) {
    $title = clean($_POST['title']); $game = clean($_POST['game']);
    $fee = $_POST['fee']; $prize = $_POST['prize']; $time = $_POST['time'];
    $pk = $_POST['per_kill']; $r1 = $_POST['rank1']; $r2 = $_POST['rank2']; $r3 = $_POST['rank3'];
    $status = $_POST['status'];

    // Image update check
    if(!empty($_FILES['img']['name'])) {
        $path = "uploads/tour_".time().".jpg";
        move_uploaded_file($_FILES['img']['tmp_name'], "../".$path);
        $conn->query("UPDATE tournaments SET image='$path' WHERE id=$id");
    }

    $sql = "UPDATE tournaments SET 
            title='$title', game_name='$game', entry_fee='$fee', prize_pool='$prize', 
            match_time='$time', per_kill='$pk', rank1='$r1', rank2='$r2', rank3='$r3', status='$status' 
            WHERE id=$id";
    
    if($conn->query($sql)) { $msg = "✅ Updated Successfully!"; }
}

$t = $conn->query("SELECT * FROM tournaments WHERE id=$id")->fetch_assoc();
include 'common/header.php';
?>

<div class="max-w-4xl mx-auto">
    <div class="flex items-center justify-between mb-8">
        <h2 class="text-2xl font-black italic uppercase text-white tracking-tighter">Edit Tournament</h2>
        <a href="tournament.php" class="bg-gray-800 px-4 py-2 rounded-xl text-xs font-bold text-gray-400 hover:text-white transition">&larr; Back to List</a>
    </div>

    <?php if($msg) echo "<div class='bg-green-600 text-white p-4 rounded-xl mb-6 font-bold shadow-lg'>$msg</div>"; ?>

    <form method="POST" enctype="multipart/form-data" class="bg-gray-800 p-8 rounded-[40px] border border-gray-700 shadow-2xl">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            <div class="space-y-1">
                <label class="text-[10px] text-gray-500 uppercase font-bold ml-1">Title</label>
                <input type="text" name="title" value="<?php echo $t['title']; ?>" class="w-full bg-gray-900 border border-gray-700 p-4 rounded-2xl text-white outline-none focus:border-yellow-500" required>
            </div>

            <div class="space-y-1">
                <label class="text-[10px] text-gray-500 uppercase font-bold ml-1">Game Name</label>
                <input type="text" name="game" value="<?php echo $t['game_name']; ?>" class="w-full bg-gray-900 border border-gray-700 p-4 rounded-2xl text-white outline-none focus:border-yellow-500" required>
            </div>

            <div class="space-y-1">
                <label class="text-[10px] text-gray-500 uppercase font-bold ml-1">Entry Fee (₹)</label>
                <input type="number" name="fee" value="<?php echo $t['entry_fee']; ?>" class="w-full bg-gray-900 border border-gray-700 p-4 rounded-2xl text-white outline-none focus:border-yellow-500" required>
            </div>

            <div class="space-y-1">
                <label class="text-[10px] text-gray-500 uppercase font-bold ml-1">Prize Pool (₹)</label>
                <input type="number" name="prize" value="<?php echo $t['prize_pool']; ?>" class="w-full bg-gray-900 border border-gray-700 p-4 rounded-2xl text-white outline-none focus:border-yellow-500" required>
            </div>

            <div class="space-y-1">
                <label class="text-[10px] text-gray-500 uppercase font-bold ml-1">Match Time</label>
                <input type="datetime-local" name="time" value="<?php echo date('Y-m-d\TH:i', strtotime($t['match_time'])); ?>" class="w-full bg-gray-900 border border-gray-700 p-4 rounded-2xl text-gray-400 outline-none focus:border-yellow-500" required>
            </div>

            <div class="space-y-1">
                <label class="text-[10px] text-gray-500 uppercase font-bold ml-1">Match Status</label>
                <select name="status" class="w-full bg-gray-900 border border-gray-700 p-4 rounded-2xl text-white outline-none focus:border-yellow-500">
                    <option value="Upcoming" <?php if($t['status']=='Upcoming') echo 'selected'; ?>>Upcoming</option>
                    <option value="Live" <?php if($t['status']=='Live') echo 'selected'; ?>>Live</option>
                    <option value="Completed" <?php if($t['status']=='Completed') echo 'selected'; ?>>Completed</option>
                </select>
            </div>

            <div class="md:col-span-2 grid grid-cols-2 sm:grid-cols-4 gap-4 mt-4 border-t border-gray-700 pt-6">
                <div class="space-y-1">
                    <label class="text-[9px] text-gray-500 uppercase font-bold">Per Kill</label>
                    <input type="number" name="per_kill" value="<?php echo $t['per_kill']; ?>" class="w-full bg-gray-900 border border-gray-700 p-3 rounded-xl text-green-500 font-bold">
                </div>
                <div class="space-y-1">
                    <label class="text-[9px] text-gray-500 uppercase font-bold">Rank 1</label>
                    <input type="number" name="rank1" value="<?php echo $t['rank1']; ?>" class="w-full bg-gray-900 border border-gray-700 p-3 rounded-xl text-yellow-500 font-bold">
                </div>
                <div class="space-y-1">
                    <label class="text-[9px] text-gray-500 uppercase font-bold">Rank 2</label>
                    <input type="number" name="rank2" value="<?php echo $t['rank2']; ?>" class="w-full bg-gray-900 border border-gray-700 p-3 rounded-xl text-gray-300 font-bold">
                </div>
                <div class="space-y-1">
                    <label class="text-[9px] text-gray-500 uppercase font-bold">Rank 3</label>
                    <input type="number" name="rank3" value="<?php echo $t['rank3']; ?>" class="w-full bg-gray-900 border border-gray-700 p-3 rounded-xl text-orange-400 font-bold">
                </div>
            </div>

            <div class="md:col-span-2 space-y-1">
                <label class="text-[10px] text-gray-500 uppercase font-bold ml-1">Change Photo (Keep blank if same)</label>
                <input type="file" name="img" class="w-full bg-gray-900 border border-gray-700 p-3 rounded-2xl text-xs text-gray-500">
            </div>

            <button name="update" class="md:col-span-2 bg-yellow-500 text-black font-black py-4 rounded-2xl shadow-xl mt-4 uppercase tracking-widest active:scale-95 transition transform">SAVE CHANGES</button>
        </div>
    </form>
</div>

<?php include 'common/bottom.php'; ?>