<?php 
require '../common/config.php';
if(!isset($_SESSION['admin_id'])) { header("Location: login.php"); exit(); }
$msg = ""; $aid = $_SESSION['admin_id'];

// 1. UPDATE LOGIN
if (isset($_POST['update_auth'])) {
    $user = clean($_POST['admin_user']);
    if (!empty($_POST['admin_pass'])) {
        $pass = password_hash($_POST['admin_pass'], PASSWORD_DEFAULT);
        $conn->query("UPDATE admin SET username='$user', password='$pass' WHERE id=$aid");
    } else { $conn->query("UPDATE admin SET username='$user' WHERE id=$aid"); }
    $msg = "✅ Admin Login Updated!";
}

// 2. UPDATE PAYMENTS & SUPPORT
if (isset($_POST['save_config'])) {
    $upi = clean($_POST['admin_upi']);
    $s_link = clean($_POST['support_link']);
    if (!empty($_FILES['qr_image']['name'])) {
        $path = "uploads/qr_" . time() . ".jpg";
        move_uploaded_file($_FILES["qr_image"]["tmp_name"], "../" . $path);
        $conn->query("UPDATE admin_settings SET upi_id='$upi', qr_code='$path', support_link='$s_link' WHERE id=1");
    } else { $conn->query("UPDATE admin_settings SET upi_id='$upi', support_link='$s_link' WHERE id=1"); }
    $msg = "✅ Configuration Saved!";
}

$settings = $conn->query("SELECT * FROM admin_settings WHERE id=1")->fetch_assoc();
$admin = $conn->query("SELECT username FROM admin WHERE id=$aid")->fetch_assoc();
include 'common/header.php';
?>

<div class="max-w-5xl">
    <h2 class="text-3xl font-black italic uppercase text-white mb-8 logo-font tracking-tighter">System Settings</h2>
    <?php if($msg) echo "<div class='bg-green-600 text-white p-4 rounded-xl mb-8 font-bold shadow-lg'>$msg</div>"; ?>

    <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <!-- SECURITY -->
        <div class="bg-gray-800 p-8 rounded-[35px] border border-gray-700 shadow-2xl">
            <h3 class="text-blue-500 font-bold mb-6 uppercase text-xs tracking-widest"><i class="fas fa-shield-alt mr-2"></i> Admin Security</h3>
            <form method="POST" class="space-y-5">
                <input type="text" name="admin_user" value="<?php echo $admin['username']; ?>" class="w-full bg-gray-900 border border-gray-700 p-4 rounded-2xl text-white outline-none focus:border-blue-500" required>
                <input type="password" name="admin_pass" placeholder="New Password (Blank to skip)" class="w-full bg-gray-900 border border-gray-700 p-4 rounded-2xl text-white outline-none focus:border-blue-500">
                <button name="update_auth" class="w-full bg-blue-600 text-white font-black py-4 rounded-2xl shadow-lg active:scale-95 transition">UPDATE LOGIN</button>
            </form>
        </div>

        <!-- PAYMENTS & SUPPORT -->
        <div class="bg-gray-800 p-8 rounded-[35px] border border-gray-700 shadow-2xl">
            <h3 class="text-yellow-500 font-bold mb-6 uppercase text-xs tracking-widest"><i class="fas fa-tools mr-2"></i> Config & Support</h3>
            <form method="POST" enctype="multipart/form-data" class="space-y-5">
                <div>
                    <label class="text-[10px] text-gray-500 uppercase font-bold ml-1">Business UPI ID</label>
                    <input type="text" name="admin_upi" value="<?php echo $settings['upi_id']; ?>" class="w-full bg-gray-900 border border-gray-700 p-4 rounded-2xl text-white" required>
                </div>
                <div>
                    <label class="text-[10px] text-gray-500 uppercase font-bold ml-1">Support Link (WhatsApp/Telegram)</label>
                    <input type="text" name="support_link" value="<?php echo $settings['support_link']; ?>" class="w-full bg-gray-900 border border-gray-700 p-4 rounded-2xl text-white" required>
                </div>
                <div class="flex items-center space-x-4">
                    <img src="../<?php echo $settings['qr_code']; ?>" class="w-12 h-12 rounded-lg border border-gray-700">
                    <input type="file" name="qr_image" class="text-xs text-gray-500">
                </div>
                <button name="save_config" class="w-full bg-yellow-500 text-black font-black py-4 rounded-2xl shadow-lg active:scale-95 transition">SAVE CONFIG</button>
            </form>
        </div>
    </div>
</div>
<?php include 'common/bottom.php'; ?>